"%windir%\Microsoft.NET\Framework64\v4.0.30319\RegAsm.exe" /codebase "%~dp0BtgSwAddIn.dll"
PAUSE
